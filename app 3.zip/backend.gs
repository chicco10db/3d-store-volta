// ================================================================
//  STORE 3D VOLTA — Google Apps Script Backend
//  1. Vai su script.google.com → Nuovo progetto
//  2. Incolla tutto questo codice
//  3. Clicca "Esegui" → setupSheets() (una volta sola)
//  4. Distribuisci → Nuova distribuzione → App web
//     - Esegui come: Me
//     - Chi ha accesso: Chiunque
//  5. Copia l'URL e incollalo in API_URL nei due file HTML
// ================================================================

const SS = SpreadsheetApp.getActiveSpreadsheet();
const PWD = '101010'; // ← cambia qui la password admin

// ── Nomi fogli ──
const SH_ORDERS   = 'Ordini';
const SH_PRODUCTS = 'Prodotti';
const SH_CONFIG   = 'Config';

// ================================================================
//  SETUP — esegui UNA sola volta per creare i fogli
// ================================================================
function setupSheets() {
  _ensureSheet(SH_ORDERS,   ['id','data','nome','email','classe','prodotti','file','note','status']);
  _ensureSheet(SH_PRODUCTS, ['id','name','desc','price','tech','bg','img','options']);
  _ensureSheet(SH_CONFIG,   ['key','value']);

  // Prodotti di default se il foglio è vuoto
  const ps = SS.getSheetByName(SH_PRODUCTS);
  if (ps.getLastRow() <= 1) {
    const defaults = [
      [1,'Portachiavi personalizzato','Il tuo nome o logo in 3D.','da 1,50€','fdm','#fff8f5','',JSON.stringify([{label:'Colore',choices:['Bianco','Nero','Rosso','Blu','Verde']}])],
      [2,'Supporto smartphone','Porta telefono da scrivania.','da 3€','fdm','#fff8f5','',JSON.stringify([{label:'Colore',choices:['Bianco','Nero','Grigio']},{label:'Orientamento',choices:['Verticale','Orizzontale']}])],
      [3,'Miniatura in resina','Figura decorativa ad alta definizione.','da 5€','resina','#f6f3ff','',JSON.stringify([{label:'Dimensione',choices:['Piccola (~5cm)','Media (~10cm)','Grande (~15cm)']}])],
      [4,'Targhetta con nome','Scritta 3D per scrivania o porta.','da 2€','fdm','#fff8f5','',JSON.stringify([{label:'Colore',choices:['Bianco','Nero','Oro']},{label:'Dimensione',choices:['Piccola','Media','Grande']}])],
      [5,'Portapenne organizer','Contenitore modulare per scrivania.','da 4€','fdm','#fff8f5','',JSON.stringify([{label:'Colore',choices:['Bianco','Nero','Verde','Blu']}])],
      [6,'Gioiello in resina','Ciondoli e orecchini in resina.','da 3€','resina','#f6f3ff','',JSON.stringify([{label:'Tipo',choices:['Ciondolo','Orecchini','Anello']}])],
      [7,'Incisione laser','Logo o scritta su legno o acrilico.','da 2€','laser','#fffbf0','',JSON.stringify([{label:'Materiale',choices:['Legno','Acrilico']},{label:'Dimensione',choices:['Piccola','Media','Grande']}])],
      [8,'Progetto su misura','Descrivi la tua idea, la realizziamo.','preventivo','custom','#f0fff6','',JSON.stringify([{label:'Tecnologia',choices:['FDM','Resina','Laser','Non so']}])],
    ];
    defaults.forEach(r => ps.appendRow(r));
  }

  // Config di default se vuoto
  const cs = SS.getSheetByName(SH_CONFIG);
  if (cs.getLastRow() <= 1) {
    const defs = [
      ['eyebrow','2^Asa STEAM — Liceo Volta FG'],
      ['headline','Stampa <span>3D</span> su misura per te'],
      ['tagline','Progettiamo e stampiamo oggetti personalizzati. Ogni acquisto finanzia il laboratorio RTL.'],
      ['about','Studenti della 2^Asa STEAM del Liceo Volta. Ogni ordine finanzia il laboratorio RTL.'],
      ['stats',JSON.stringify([{n:'6',l:'Stampanti attive'},{n:'3',l:'Tecnologie'},{n:'5',l:'Materiali'},{n:'100%',l:'Al laboratorio'}])],
      ['prezzi',JSON.stringify({
        prog:4.5,
        'fdm-pla':{ore:1.2,mat:0.018},
        'fdm-petg':{ore:1.4,mat:0.022},
        'fdm-abs':{ore:1.6,mat:0.020},
        'fdm-tpu':{ore:1.5,mat:0.030},
        'fdm-asa':{ore:1.5,mat:0.025},
        resina:{ore:4.5,ml:0.08},
        laser:{piccolo:2,medio:5,grande:10}
      })]
    ];
    defs.forEach(r => cs.appendRow(r));
  }

  Logger.log('Setup completato!');
}

function _ensureSheet(name, headers) {
  let s = SS.getSheetByName(name);
  if (!s) {
    s = SS.insertSheet(name);
    s.appendRow(headers);
    s.getRange(1, 1, 1, headers.length)
      .setFontWeight('bold')
      .setBackground('#e8601f')
      .setFontColor('#ffffff');
    s.setFrozenRows(1);
  }
  return s;
}

// ================================================================
//  ENTRY POINT — riceve tutte le richieste HTTP
// ================================================================
function doGet(e) {
  return _handle(e);
}

function doPost(e) {
  return _handle(e);
}

function _handle(e) {
  try {
    const p = e.parameter || {};
    const body = _parseBody(e);
    const action = p.action || body.action || '';

    // ── Azioni pubbliche (senza password) ──
    if (action === 'getProducts') return _json(_getProducts());
    if (action === 'getConfig')   return _json(_getConfig());
    if (action === 'addOrder')    return _json(_addOrder(body));

    // ── Azioni admin (richiedono password) ──
    const pwd = p.pwd || body.pwd || '';
    if (pwd !== PWD) return _json({ok:false, error:'Password errata'});

    if (action === 'getOrders')       return _json(_getOrders());
    if (action === 'updateOrderStatus') return _json(_updateOrderStatus(body));
    if (action === 'deleteOrder')     return _json(_deleteOrder(body));
    if (action === 'saveProduct')     return _json(_saveProduct(body));
    if (action === 'deleteProduct')   return _json(_deleteProduct(body));
    if (action === 'saveConfig')      return _json(_saveConfig(body));

    return _json({ok:false, error:'Azione non trovata: ' + action});
  } catch(err) {
    return _json({ok:false, error: err.toString()});
  }
}

function _parseBody(e) {
  try {
    if (e.postData && e.postData.contents) {
      return JSON.parse(e.postData.contents);
    }
  } catch(_) {}
  return e.parameter || {};
}

function _json(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// ================================================================
//  PRODOTTI
// ================================================================
function _getProducts() {
  const s = SS.getSheetByName(SH_PRODUCTS);
  if (!s || s.getLastRow() <= 1) return {ok:true, data:[]};
  const rows = s.getRange(2, 1, s.getLastRow()-1, 8).getValues();
  const data = rows
    .filter(r => r[0] !== '')
    .map(r => ({
      id:      Number(r[0]),
      name:    String(r[1]),
      desc:    String(r[2]),
      price:   String(r[3]),
      tech:    String(r[4]),
      bg:      String(r[5]) || '#fff8f5',
      img:     String(r[6]),
      options: _parseJson(r[7], [])
    }));
  return {ok:true, data};
}

function _saveProduct(body) {
  const s = SS.getSheetByName(SH_PRODUCTS);
  const id = Number(body.id) || 0;
  const row = [
    body.id || _newProductId(),
    body.name || '',
    body.desc || '',
    body.price || '',
    body.tech || 'fdm',
    body.bg || '#fff8f5',
    body.img || '',
    JSON.stringify(body.options || [])
  ];

  if (id) {
    // modifica esistente
    const rows = s.getLastRow() > 1 ? s.getRange(2,1,s.getLastRow()-1,1).getValues() : [];
    for (let i = 0; i < rows.length; i++) {
      if (Number(rows[i][0]) === id) {
        s.getRange(i+2, 1, 1, 8).setValues([row]);
        return {ok:true};
      }
    }
  }
  // nuovo
  row[0] = _newProductId();
  s.appendRow(row);
  return {ok:true, id: row[0]};
}

function _deleteProduct(body) {
  const s = SS.getSheetByName(SH_PRODUCTS);
  const id = Number(body.id);
  const rows = s.getLastRow() > 1 ? s.getRange(2,1,s.getLastRow()-1,1).getValues() : [];
  for (let i = rows.length-1; i >= 0; i--) {
    if (Number(rows[i][0]) === id) { s.deleteRow(i+2); return {ok:true}; }
  }
  return {ok:false, error:'Prodotto non trovato'};
}

function _newProductId() {
  const s = SS.getSheetByName(SH_PRODUCTS);
  if (s.getLastRow() <= 1) return 1;
  const ids = s.getRange(2,1,s.getLastRow()-1,1).getValues().map(r=>Number(r[0])).filter(Boolean);
  return ids.length ? Math.max(...ids)+1 : 1;
}

// ================================================================
//  ORDINI
// ================================================================
function _addOrder(body) {
  const s = SS.getSheetByName(SH_ORDERS);
  const id = '#' + String(_newOrderId()).padStart(3,'0');
  const data = new Date().toLocaleDateString('it-IT');
  s.appendRow([id, data, body.nome||'', body.email||'', body.classe||'—', body.prodotti||'', body.file||'', body.note||'—', 'nuovo']);
  return {ok:true, id};
}

function _getOrders() {
  const s = SS.getSheetByName(SH_ORDERS);
  if (!s || s.getLastRow() <= 1) return {ok:true, data:[]};
  const rows = s.getRange(2,1,s.getLastRow()-1,9).getValues();
  const data = rows
    .filter(r => r[0] !== '')
    .map(r => ({
      id:       String(r[0]),
      data:     String(r[1]),
      nome:     String(r[2]),
      email:    String(r[3]),
      classe:   String(r[4]),
      prodotti: String(r[5]),
      file:     String(r[6]),
      note:     String(r[7]),
      status:   String(r[8])
    }))
    .reverse();
  return {ok:true, data};
}

function _updateOrderStatus(body) {
  const s = SS.getSheetByName(SH_ORDERS);
  const rows = s.getLastRow() > 1 ? s.getRange(2,1,s.getLastRow()-1,1).getValues() : [];
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][0]) === String(body.id)) {
      s.getRange(i+2, 9).setValue(body.status);
      return {ok:true};
    }
  }
  return {ok:false, error:'Ordine non trovato'};
}

function _deleteOrder(body) {
  const s = SS.getSheetByName(SH_ORDERS);
  const rows = s.getLastRow() > 1 ? s.getRange(2,1,s.getLastRow()-1,1).getValues() : [];
  for (let i = rows.length-1; i >= 0; i--) {
    if (String(rows[i][0]) === String(body.id)) { s.deleteRow(i+2); return {ok:true}; }
  }
  return {ok:false, error:'Ordine non trovato'};
}

function _newOrderId() {
  const s = SS.getSheetByName(SH_ORDERS);
  if (s.getLastRow() <= 1) return 1;
  return s.getLastRow() - 1 + 1;
}

// ================================================================
//  CONFIG (prezzi, testi sito)
// ================================================================
function _getConfig() {
  const s = SS.getSheetByName(SH_CONFIG);
  if (!s || s.getLastRow() <= 1) return {ok:true, data:{}};
  const rows = s.getRange(2,1,s.getLastRow()-1,2).getValues();
  const data = {};
  rows.forEach(r => {
    if (r[0]) data[String(r[0])] = _parseJson(r[1], r[1]);
  });
  return {ok:true, data};
}

function _saveConfig(body) {
  const s = SS.getSheetByName(SH_CONFIG);
  const cfg = body.config || {};
  Object.entries(cfg).forEach(([key, value]) => {
    const val = typeof value === 'object' ? JSON.stringify(value) : String(value);
    // cerca chiave esistente
    if (s.getLastRow() > 1) {
      const keys = s.getRange(2,1,s.getLastRow()-1,1).getValues();
      for (let i = 0; i < keys.length; i++) {
        if (String(keys[i][0]) === key) { s.getRange(i+2,2).setValue(val); return; }
      }
    }
    s.appendRow([key, val]);
  });
  return {ok:true};
}

// ================================================================
//  UTIL
// ================================================================
function _parseJson(v, fallback) {
  try { return JSON.parse(v); } catch(_) { return fallback; }
}
